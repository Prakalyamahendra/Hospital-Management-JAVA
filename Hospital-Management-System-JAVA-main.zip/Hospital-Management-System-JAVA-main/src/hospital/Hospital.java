package hospital;

public class Hospital {

    public static void main(String[] args) {
       
    }
    
}
